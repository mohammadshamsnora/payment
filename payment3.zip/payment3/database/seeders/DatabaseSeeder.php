<?php

namespace Database\Seeders;

use App\Models\Buyer;
use App\Models\Seller;
use App\Models\Status;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);


        Seller::query()->insert([

            ['title'=>'first-seller','count'=>10,'amount'=>50000,'validity'=>70000],
            ['title'=>'second-seller','count'=>20,'amount'=>100000,'validity'=>100000],
            ['title'=>'third-seller','count'=>30,'amount'=>150000,'validity'=>50000],
            ['title'=>'fourth-seller','count'=>40,'amount'=>200000,'validity'=>200000],




        ]);



        Buyer::query()->insert([

            ['title'=>'first-buyer','name'=>'ali','count'=>10,'amount'=>50000],
            ['title'=>'second-buyer','name'=>'mohammad','count'=>20,'amount'=>100000],
            ['title'=>'third-buyer','name'=>'reza','count'=>30,'amount'=>150000],
            ['title'=>'fourth-buyer','name'=>'hasan','count'=>40,'amount'=>200000],


        ]);


        Status::query()->insert([

            ['title'=>'درحال بررسی'],
            ['title'=>'تایید شده'],
            ['title'=>'عدم تایید']





        ]);




    }
}
