<?php

namespace App\Http\Controllers;

use App\Http\Resources\OrderResource;
use App\Models\Buyer;
use App\Models\Order;
use App\Models\Seller;
use Illuminate\Http\Request;

class PaymentController extends Controller
{



        public function store(Request $request){


            $seller=Seller::query()->where('id',$request->seller_id)->first();
            $buyer=Buyer::query()->where('id',$request->buyer_id)->first();
            $max_seller_validity=$seller->validity;
            $request_buyer_validity=$request->validity;
            $seller_amount=$seller->amount;
            $buyer_amount=$buyer->amount;
            $seler_count=$seller->count;
            $buyer_count=$buyer->count;
            $owner_buyer_validity=$buyer->validity;

            $order_exists=Order::query()->where('seller_id',$request->seller_id)->where('buyer_id',$request->buyer_id)->exists();


            if($order_exists){

                return response()->json([


                    'data'=>[

                        'message'=>'wrong:the same order'

                    ]

                    ]);

            }


            // dd($seller->count);
            if(!($seller_amount<=$buyer_amount && $seler_count<=$buyer_count && $request_buyer_validity<=$max_seller_validity) ){


                    return response()->json([


                        'data'=>[

                            'message'=>'the wrong has been taken'

                        ]

                        ]);

            }

            




      $order=Order::query()->create([


                    'buyer_id'=>$request->buyer_id,
                    'seller_id'=>$request->seller_id,
                    'status_id'=>1,
                    'validity'=>$request->validity


            ]);




                return response()->json([


                    'data'=>[

                        'message'=>'order added',
                        'order'=>new OrderResource($order)

                    ]



                ]);



        }





}
