<?php

namespace App\Http\Controllers;

use App\Http\Resources\OrderResource;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderStausController extends Controller
{



        public function store(Request $request){


           $order=Order::query()->where('id',$request->order_id)->first();
           $old_owner_buyer_validity=$order->buyer->validity;
           $new_owner_buyer_validity=$old_owner_buyer_validity+$order->validity;

            if($request->status==1){

                    $order->update([


                        'status_id'=>2



                    ]);
                    $order->buyer->update([

                        'validity'=>$new_owner_buyer_validity


                    ]);




            }elseif($request->status==0){

                $order->update([


                    'status_id'=>3



                ]);
               


            }






            return response()->json([


                'data'=>[


                    'order'=>new OrderResource($order)

                ]



            ]);



        }








}
