<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

protected $guarded=[];



public function buyer(){


    return $this->belongsTo(Buyer::class);


}

public function status(){


    return $this->belongsTo(Status::class);


}


public function Seller(){


    return $this->belongsTo(Seller::class);


}




}
