<?php

use App\Http\Controllers\OrderStausController;
use App\Http\Controllers\PaymentController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');



Route::post('/request',[PaymentController::class,'store']);
Route::post('/request/status',[ OrderStausController::class,'store']);
